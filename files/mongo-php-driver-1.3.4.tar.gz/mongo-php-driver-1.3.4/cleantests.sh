#!/bin/sh

rm tests/*/*.diff
rm tests/*/*.exp
rm tests/*/*.log
rm tests/*/*.out
rm tests/*/*.mem
rm tests/*/*.php
rm tests/*/*.sh

