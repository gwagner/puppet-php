db = connect("admin");
db.addUser("testUser", "testPass");
